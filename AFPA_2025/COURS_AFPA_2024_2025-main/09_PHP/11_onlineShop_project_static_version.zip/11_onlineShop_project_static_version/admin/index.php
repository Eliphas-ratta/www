<?php

// Accueil du BACK OFFICE

require_once("../inc/init.php");
require_once("inc/header.php");

?>

<!-- BODY -->

<h1 class='mb-5 text-center col-12'>Welcome to your backOffice</h1>
<p>Select one action in the menu</p>


<?php
    require_once("inc/footer.php");
?>